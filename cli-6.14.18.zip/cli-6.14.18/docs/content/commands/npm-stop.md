---
title: npm-stop
section: 1
description: Stop a package
---

### Synopsis

```bash
npm stop [-- <args>]
```

### Description

This runs a package's "stop" script, if one was provided.

### See Also

* [npm run-script](/commands/npm-run-script)
* [npm scripts](/using-npm/scripts)
* [npm test](/commands/npm-test)
* [npm start](/commands/npm-start)
* [npm restart](/commands/npm-restart)
